import sys
import re
import codecs

def processTestFile(classfilename,wekafilename) :
	fin1 = codecs.open(classfilename)
	fin2 = codecs.open(wekafilename)
	
	for inputline in fin2 :
		inputline = inputline.strip('\r\n').strip()
		#print inputline
		if len(inputline) == 0 or inputline.startswith('@') :
			print inputline
			continue
		inputList = inputline.split(',')
		classline = fin1.next().strip('\r\n').strip()
		inputList[len(inputList)-1] = classline
		outputline = ','.join(inputList)
		print outputline

	fin1.close()
	fin2.close()


if __name__ == '__main__' :
	#test_train_option = sys.argv[1]
	classfilename = sys.argv[1]
	wekafilename = sys.argv[2]
	
	processTestFile(classfilename,wekafilename)
	
